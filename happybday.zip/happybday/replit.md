# Birthday Greeting Website

## Overview
This is a beautiful, interactive birthday greeting website featuring an animated heart tree with falling petals. When clicked, it displays personalized birthday messages with music and animations.

## Project Type
Static HTML/CSS/JavaScript website - no build process required

## Technology Stack
- **Frontend**: Pure HTML5, CSS3, JavaScript
- **Libraries**: 
  - jQuery for DOM manipulation
  - Jscex for async animation control
  - Custom canvas-based animation engine
- **Server**: Python HTTP server (development only)

## Project Structure
```
/
├── index.html              # Main HTML page
├── file/                   # Assets directory
│   ├── default.css        # Styles
│   ├── functions.js       # Helper functions
│   ├── love.js            # Main animation logic
│   ├── jquery.min.js      # jQuery library
│   └── jscex-*.js         # Jscex async libraries
├── aud.mp3                # Background music
├── img.png                # Images
└── img2.png
```

## Features
- Interactive animated heart tree with growing branches
- Falling flower petals animation
- Birthday message reveal on click
- Background music playback
- Canvas-based graphics and animations
- Customizable birthday messages

## Development
The website runs on Python's built-in HTTP server on port 5000:
```bash
python -m http.server 5000
```

## Deployment
Configured as a static site deployment. All files in the root directory are served directly.

## Recent Changes
- **Nov 26, 2025**: Initial setup in Replit environment
  - Configured Python HTTP server for development
  - Set up static site deployment
  - Verified all animations and audio working correctly

## Customization
To customize the birthday message, edit the `<div id="code">` section in `index.html`.
